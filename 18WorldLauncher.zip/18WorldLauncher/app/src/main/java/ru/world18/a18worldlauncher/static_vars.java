package ru.world18.a18worldlauncher;


import android.content.SharedPreferences;
import android.os.Bundle;
import android.webkit.WebView;

public class static_vars {
    public static Login activity;
    public static User user;
    public static SharedPreferences mSettings;
    public static Bundle savedInstanceState;
    public static WebView mWebView;
}